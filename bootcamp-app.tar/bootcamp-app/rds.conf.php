<?php $RDS_URL="demooo-databaseprimaryinstance-9inr8rckkwg9.ch9bvmmlibrp.us-east-1.rds.amazonaws.com"; $RDS_DB="wordpress"; $RDS_user="admin"; $RDS_pwd="password"; ?>
