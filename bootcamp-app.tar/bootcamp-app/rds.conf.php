<?php $RDS_URL="demo-databaseprimaryinstance-yzltfovhsdf6.ch9bvmmlibrp.us-east-1.rds.amazonaws.com"; $RDS_DB="db"; $RDS_user="admin"; $RDS_pwd="password"; ?>
<!-- <?php $RDS_URL=""; $RDS_DB=""; $RDS_user=""; $RDS_pwd=""; ?> -->
