<div id="header"><a href="/"><img src="logo.png" width="40" /></a></div>

<div id='menu'>
<ul>
  <li><a href="load.php">Load Test</a></li>
  <li><a href="rds.php">RDS</a></li>
</ul>
</div>
